#include <matrixop.h>
static double DymArrays1[3]={0.0, 0.0, 1.0};
static double DymArrays0[3]={0.0, 1.0, 0.0};
/* Declaration of C-structs */
struct DymStruc0;
struct DymStruc1;
struct DymStruc2_wheelInitials;
struct DymStruc2;
struct DymStruc0 {
  int  NWheels_0member;
  double  mecanumAngle_0member;
  int  nRollers_0member;
  const char*  name_0member;
  double  platformAxialMoi_0member;
  double  platformMass_0member;
  double  platformOrthogonalMoi_0member;
  double  platformRadius_0member;
  double  rollerAxialMoi_0member;
  double  rollerHalfAngle_0member;
  double  rollerLength_0member;
  double  rollerMass_0member;
  double  rollerOrthogonalMoi_0member;
  double  rollerRadius_0member;
  double  wheelHubAxialMoi_0member;
  double  wheelHubMass_0member;
  double  wheelHubOrthogonalMoi_0member;
  double  wheelHubRadius_0member;
  double  wheelRadius_0member;
};
DYMOLA_STATIC struct DymStruc0 DymStruc0_construct(int   NWheels_02, double   
  mecanumAngle_02, int   nRollers_02, const char*   name_02, double   
  platformAxialMoi_02, double   platformMass_02, double   platformOrthogonalMoi_02,
   double   platformRadius_02, double   rollerAxialMoi_02, double   
  rollerHalfAngle_02, double   rollerLength_02, double   rollerMass_02, double  
   rollerOrthogonalMoi_02, double   rollerRadius_02, double   wheelHubAxialMoi_02,
   double   wheelHubMass_02, double   wheelHubOrthogonalMoi_02, double   
  wheelHubRadius_02, double   wheelRadius_02) {
  struct DymStruc0 dummy_0;
  dummy_0.NWheels_0member = NWheels_02;
  dummy_0.mecanumAngle_0member = mecanumAngle_02;
  dummy_0.nRollers_0member = nRollers_02;
  dummy_0.name_0member = name_02;
  dummy_0.platformAxialMoi_0member = platformAxialMoi_02;
  dummy_0.platformMass_0member = platformMass_02;
  dummy_0.platformOrthogonalMoi_0member = platformOrthogonalMoi_02;
  dummy_0.platformRadius_0member = platformRadius_02;
  dummy_0.rollerAxialMoi_0member = rollerAxialMoi_02;
  dummy_0.rollerHalfAngle_0member = rollerHalfAngle_02;
  dummy_0.rollerLength_0member = rollerLength_02;
  dummy_0.rollerMass_0member = rollerMass_02;
  dummy_0.rollerOrthogonalMoi_0member = rollerOrthogonalMoi_02;
  dummy_0.rollerRadius_0member = rollerRadius_02;
  dummy_0.wheelHubAxialMoi_0member = wheelHubAxialMoi_02;
  dummy_0.wheelHubMass_0member = wheelHubMass_02;
  dummy_0.wheelHubOrthogonalMoi_0member = wheelHubOrthogonalMoi_02;
  dummy_0.wheelHubRadius_0member = wheelHubRadius_02;
  dummy_0.wheelRadius_0member = wheelRadius_02;
  return dummy_0;
}
struct DymStruc1 {
  const char*  name_0member;
  double  omega_0member;
  RealArray   omegaVec_0member;
  double  vAbs_0member;
  double  vDirAngle_0member;
  RealArray   vVec_0member;
};
DYMOLA_STATIC struct DymStruc1 DymStruc1_construct(const char*   name_02, double 
    omega_02, RealArray    omegaVec_02, double   vAbs_02, double   vDirAngle_02,
   RealArray    vVec_02) {
  struct DymStruc1 dummy_0;
  dummy_0.name_0member = name_02;
  dummy_0.omega_0member = omega_02;
  dummy_0.omegaVec_0member = omegaVec_02;
  dummy_0.vAbs_0member = vAbs_02;
  dummy_0.vDirAngle_0member = vDirAngle_02;
  dummy_0.vVec_0member = vVec_02;
  return dummy_0;
}
DYMOLA_STATIC RealArray DymStruc2_wheelInitials_construct(int nRecord0, ...) {
  int inRecord0;
  va_list ap;
  RealArray dummy_0;
  dummy_0=RealTemporary(2, nRecord0, (sizeof(struct DymStruc1)+sizeof(double)-1)/sizeof(double));
  va_start(ap, nRecord0);
  for(inRecord0=1;inRecord0<=nRecord0;inRecord0++) {
  (*(struct DymStruc1*)RecordElement(dummy_0, inRecord0, 1))=va_arg(ap, 
    struct DymStruc1);
  }
  va_end(ap);
  return dummy_0;
}
struct DymStruc2 {
  RealArray   gravity_0member;
  struct DymStruc1 initials_0member;
  struct DymStruc0 params_0member;
  RealArray   platformCenter_0member;
  RealArray   platformQuaternion_0member;
  RealArray   wheelAxisDirections_0member;
  RealArray   wheelCenters_0member;
  RealArray  wheelInitials_0member;
  RealArray   wheelQuaternions_0member;
};
DYMOLA_STATIC struct DymStruc2 DymStruc2_construct(RealArray    gravity_02, 
  struct DymStruc1  initials_02, struct DymStruc0  params_02, RealArray    
  platformCenter_02, RealArray    platformQuaternion_02, RealArray    
  wheelAxisDirections_02, RealArray    wheelCenters_02, RealArray  
  wheelInitials_02, RealArray    wheelQuaternions_02) {
  struct DymStruc2 dummy_0;
  dummy_0.gravity_0member = gravity_02;
  dummy_0.initials_0member = initials_02;
  dummy_0.params_0member = params_02;
  dummy_0.platformCenter_0member = platformCenter_02;
  dummy_0.platformQuaternion_0member = platformQuaternion_02;
  dummy_0.wheelAxisDirections_0member = wheelAxisDirections_02;
  dummy_0.wheelCenters_0member = wheelCenters_02;
  dummy_0.wheelInitials_0member = wheelInitials_02;
  dummy_0.wheelQuaternions_0member = wheelQuaternions_02;
  return dummy_0;
}
/* Prototypes for functions used in model */
DYMOLA_STATIC struct DymStruc2  MbsLite_Examples_OmniVehicle_CalculateOmniVehicleParams
  (struct DymStruc0 params0_0, struct DymStruc1 initials0_0, RealArray   
  gravity0_0, RealArray   platformQuaternion0_0);
DYMOLA_STATIC struct DymStruc1  MbsLite_Examples_OmniVehicle_Initials(
  const char*  name0_0, double  omega0_0, double  vAbs0_0, double  vDirAngle0_0,
   RealArray   vVec0_0, RealArray   omegaVec0_0);
DYMOLA_STATIC struct DymStruc2  MbsLite_Examples_OmniVehicle_OmniVehicleParams(
  struct DymStruc0 params0_0, struct DymStruc1 initials0_0, RealArray   
  gravity0_0, RealArray   platformQuaternion0_0, RealArray   platformCenter0_0, 
  RealArray   wheelCenters0_0, RealArray   wheelAxisDirections0_0, RealArray   
  wheelQuaternions0_0, RealArray wheelInitials0_0);
DYMOLA_STATIC RealArray    MbsLite_Util_Euler(RealArray   origin0_0, RealArray  
   point0_0, RealArray   velocityOfOrigin0_0, RealArray   omega0_0);
DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QMult(RealArray   q10_0, 
  RealArray   q20_0);
DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QRot(double  angle0_0, 
  RealArray   axis0_0);
DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QToT(RealArray   q0_0);
/* Codes used in model */
/* Flattened Modelica model:

function MbsLite.Examples.OmniVehicle.CalculateOmniVehicleParams
  input MbsLite.Examples.OmniVehicle.Params params;
  input MbsLite.Examples.OmniVehicle.Initials initials;
  input Real gravity[3];
  input Real platformQuaternion[4];
  output MbsLite.Examples.OmniVehicle.OmniVehicleParams omniVehicleParams;
protected 
  constant Real wheelNoise := 0 "to reduce the probabiilty of multiple simultaneous impacts";
  Integer nActual := params.nRollers;
  Integer NActual := params.NWheels;
  Real platformCenter[3];
  Real wheelCenters[NActual, 3];
  Real wheelAxisDirections[NActual, 3];
  parameter MbsLite.Examples.OmniVehicle.Initials wheelInitials[3];
  Real wheelAxisAngles[NActual] "Angles between rightward direction (x1, i.e. forward direction) and wheel axes";
  Real wheelQuaternionsRel[NActual, 4] "Directions of x1 of each wheel relative to platform";
  Real wheelQuaternionsAbs[NActual, 4] "Directions of x1 of each wheel in global coords";
  Real wheelOmegaRelLocal[3] "Initial relative angular velocities of wheels in local coords";
  Real wheelV0s[NActual, 3] "Initial velocities of wheels in global coords";
  Real wheelOmega0s[NActual, 3] "Initial angular velocities of wheels in global coords";
  public 
algorithm 
  nActual := params.nRollers;
  NActual := params.NWheels;
  platformCenter := params.wheelRadius*{0, 1, 0};
  for i in (1:NActual) loop
    wheelAxisAngles[i] := 6.28318530717959*(i-1)/NActual;
    wheelQuaternionsRel[i, :] := MbsLite.Util.Quaternions.QMult(MbsLite.Util.Quaternions.QRot
      (1.5707963267949+wheelAxisAngles[i], {0, 1, 0}), MbsLite.Util.Quaternions.QRot
      ((i-1)*wheelNoise, {0, 0, 1}));
    wheelQuaternionsAbs[i, :] := MbsLite.Util.Quaternions.QMult(platformQuaternion,
       wheelQuaternionsRel[i, :]);
    wheelAxisDirections[i, :] := MbsLite.Util.Quaternions.QToT(wheelQuaternionsAbs
      [i, :])*{0, 0, 1};
    wheelCenters[i, :] := platformCenter+params.platformRadius*wheelAxisDirections
      [i, :];
    wheelOmegaRelLocal :=  -params.platformRadius*initials.omega*{0, 0, 1}/
      params.wheelRadius;
    wheelV0s[i, :] := MbsLite.Util.Euler(platformCenter, wheelCenters[i, :], 
      initials.vVec, initials.omegaVec);
    wheelOmega0s[i, :] := initials.omegaVec+MbsLite.Util.Quaternions.QToT(
      wheelQuaternionsAbs[i, :])*wheelOmegaRelLocal;
    wheelInitials[i] := MbsLite.Examples.OmniVehicle.Initials("OmniWheel["+
             String(i, true, 0)+"] initials", 1E+060, 1E+060, 1E+060, wheelV0s[i,
       :], wheelOmega0s[i, :]);
  end for;
  omniVehicleParams := MbsLite.Examples.OmniVehicle.OmniVehicleParams(
    params, 
    initials, 
    gravity, 
    platformQuaternion, 
    platformCenter, 
    wheelCenters, 
    wheelAxisDirections, 
    wheelQuaternionsAbs, 
    wheelInitials);
end MbsLite.Examples.OmniVehicle.CalculateOmniVehicleParams;
*/



DYMOLA_STATIC struct DymStruc2  MbsLite_Examples_OmniVehicle_CalculateOmniVehicleParams
  (struct DymStruc0 params0_0, struct DymStruc1 initials0_0, RealArray   
  gravity0_0, RealArray   platformQuaternion0_0) {
  PushContext("MbsLite.Examples.OmniVehicle.CalculateOmniVehicleParams")
  AssertModelica(RealSize( gravity0_0,1)==3,"size(gravity, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( platformQuaternion0_0,1)==4,"size(platformQuaternion, 1) == 4","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    struct DymStruc2  omniVehicleParams0_0;
    double   wheelNoise0_0;
    int   nActual0_0;
    int   NActual0_0;
    RealArray    platformCenter0_0;
    RealArray    wheelCenters0_0;
    RealArray    wheelAxisDirections0_0;
    RealArray  wheelInitials0_0;
    RealArray    wheelAxisAngles0_0;
    RealArray    wheelQuaternionsRel0_0;
    RealArray    wheelQuaternionsAbs0_0;
    RealArray    wheelOmegaRelLocal0_0;
    RealArray    wheelV0s0_0;
    RealArray    wheelOmega0s0_0;
    MarkObject retmark_ = PushMark();
    omniVehicleParams0_0.params_0member.name_0member="";
    omniVehicleParams0_0.params_0member.NWheels_0member=0;
    omniVehicleParams0_0.params_0member.nRollers_0member=0;
    omniVehicleParams0_0.params_0member.mecanumAngle_0member=0;
    omniVehicleParams0_0.params_0member.platformRadius_0member=0;
    omniVehicleParams0_0.params_0member.wheelRadius_0member=0;
    omniVehicleParams0_0.params_0member.platformMass_0member=0;
    omniVehicleParams0_0.params_0member.wheelHubMass_0member=0;
    omniVehicleParams0_0.params_0member.rollerMass_0member=0;
    omniVehicleParams0_0.params_0member.rollerHalfAngle_0member=0;
    omniVehicleParams0_0.params_0member.wheelHubRadius_0member=0;
    omniVehicleParams0_0.params_0member.rollerRadius_0member=0;
    omniVehicleParams0_0.params_0member.rollerLength_0member=0;
    omniVehicleParams0_0.params_0member.platformAxialMoi_0member=0;
    omniVehicleParams0_0.params_0member.platformOrthogonalMoi_0member=0;
    omniVehicleParams0_0.params_0member.wheelHubAxialMoi_0member=0;
    omniVehicleParams0_0.params_0member.wheelHubOrthogonalMoi_0member=0;
    omniVehicleParams0_0.params_0member.rollerAxialMoi_0member=0;
    omniVehicleParams0_0.params_0member.rollerOrthogonalMoi_0member=0;
    omniVehicleParams0_0.initials_0member.name_0member="";
    omniVehicleParams0_0.initials_0member.omega_0member=0;
    omniVehicleParams0_0.initials_0member.vAbs_0member=0;
    omniVehicleParams0_0.initials_0member.vDirAngle_0member=0;
    omniVehicleParams0_0.initials_0member.vVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.initials_0member.vVec_0member, 0);
    omniVehicleParams0_0.initials_0member.omegaVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.initials_0member.omegaVec_0member, 0);
    omniVehicleParams0_0.gravity_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.gravity_0member, 0);
    omniVehicleParams0_0.platformQuaternion_0member=RealTemporary( 1, 4);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.platformQuaternion_0member, 0);
    omniVehicleParams0_0.platformCenter_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.platformCenter_0member, 0);
    omniVehicleParams0_0.wheelCenters_0member=RealTemporary( 2, -1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.wheelCenters_0member, 0);
    omniVehicleParams0_0.wheelAxisDirections_0member=RealTemporary( 2, -1, 3);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.wheelAxisDirections_0member, 0);
    omniVehicleParams0_0.wheelQuaternions_0member=RealTemporary( 2, -1, 4);
    RePushMark(&retmark_);
    RealFillAssign( omniVehicleParams0_0.wheelQuaternions_0member, 0);
    omniVehicleParams0_0.wheelInitials_0member=RealTemporary(2, 3, (sizeof(
      struct DymStruc1)+sizeof(Real)-1)/sizeof(Real));
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       1, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       1, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       1, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       1, 1)).vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 1, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 1, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 1, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 1, 1)).omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       2, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       2, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       2, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       2, 1)).vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 2, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 2, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 2, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 2, 1)).omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       3, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       3, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       3, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
       3, 1)).vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 3, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 3, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member, 3, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
      wheelInitials_0member, 3, 1)).omegaVec_0member, 0);
    RePushMark(&retmark_);
    wheelNoise0_0 = 0;
    nActual0_0 = params0_0.nRollers_0member;
    NActual0_0 = params0_0.NWheels_0member;
    platformCenter0_0=RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( platformCenter0_0, 0);
    wheelCenters0_0=RealTemporary( 2, NActual0_0, 3);
    PushMark();
    RealFillAssign( wheelCenters0_0, 0);
    wheelAxisDirections0_0=RealTemporary( 2, NActual0_0, 3);
    PushMark();
    RealFillAssign( wheelAxisDirections0_0, 0);
    wheelInitials0_0=RealTemporary(2, 3, (sizeof(struct DymStruc1)+sizeof(Real)-1)/sizeof(Real));
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).vDirAngle_0member
      =0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).vVec_0member=
      RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).
      vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1)).
      omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).vDirAngle_0member
      =0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).vVec_0member=
      RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).
      vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1)).
      omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).name_0member="";
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).omega_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).vDirAngle_0member
      =0;
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).vVec_0member=
      RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).
      vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1)).
      omegaVec_0member, 0);
    PushMark();
    wheelAxisAngles0_0=RealTemporary( 1, NActual0_0);
    PushMark();
    RealFillAssign( wheelAxisAngles0_0, 0);
    wheelQuaternionsRel0_0=RealTemporary( 2, NActual0_0, 4);
    PushMark();
    RealFillAssign( wheelQuaternionsRel0_0, 0);
    wheelQuaternionsAbs0_0=RealTemporary( 2, NActual0_0, 4);
    PushMark();
    RealFillAssign( wheelQuaternionsAbs0_0, 0);
    wheelOmegaRelLocal0_0=RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( wheelOmegaRelLocal0_0, 0);
    wheelV0s0_0=RealTemporary( 2, NActual0_0, 3);
    PushMark();
    RealFillAssign( wheelV0s0_0, 0);
    wheelOmega0s0_0=RealTemporary( 2, NActual0_0, 3);
    PushMark();
    RealFillAssign( wheelOmega0s0_0, 0);
    /* Start of real code */
      nActual0_0 = params0_0.nRollers_0member;
      NActual0_0 = params0_0.NWheels_0member;
      RealAssign (platformCenter0_0, RealScale (RealTemporaryDense( DymArrays0, 1,
         3),params0_0.wheelRadius_0member));
      Release();
      {
        int end_ = NActual0_0;
        int i0_0_0;
        for(i0_0_0 = 1;i0_0_0 <= end_;i0_0_0 += 1) {
          SetRealElement(divmacro(6.28318530717959*(i0_0_0-1),"6.28318530717959*(i-1)",
            NActual0_0,"NActual"), wheelAxisAngles0_0, (SizeType)( i0_0_0 ));
          RealPutSub( MbsLite_Util_Quaternions_QMult(MbsLite_Util_Quaternions_QRot
            (1.5707963267949+RealElement( wheelAxisAngles0_0, (SizeType)( i0_0_0
             )), RealTemporaryDense( DymArrays0, 1, 3)), MbsLite_Util_Quaternions_QRot
            ((i0_0_0-1)*wheelNoise0_0, RealTemporaryDense( DymArrays1, 1, 3))), 
            wheelQuaternionsRel0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark);
          Release();
          RealPutSub( MbsLite_Util_Quaternions_QMult(platformQuaternion0_0, 
            RealGetSub( wheelQuaternionsRel0_0 , Index, (Integer)( i0_0_0) ,
            Colon  , EndMark)), wheelQuaternionsAbs0_0 , Index, (Integer)( 
            i0_0_0) ,Colon  , EndMark);
          Release();
          RealPutSub( RealMultiplyMV (MbsLite_Util_Quaternions_QToT(RealGetSub( 
            wheelQuaternionsAbs0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark)),
            RealTemporaryDense( DymArrays1, 1, 3)), wheelAxisDirections0_0 ,
             Index, (Integer)( i0_0_0) ,Colon  , EndMark);
          Release();
          RealPutSub( RealAdd (platformCenter0_0,RealScale (RealGetSub( 
            wheelAxisDirections0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark),
            params0_0.platformRadius_0member)), wheelCenters0_0 , Index, 
            (Integer)( i0_0_0) ,Colon  , EndMark);
          Release();
          RealAssign (wheelOmegaRelLocal0_0, RealMinus( RealScaleDiv (RealScale 
            (RealTemporaryDense( DymArrays1, 1, 3),params0_0.platformRadius_0member
            *initials0_0.omega_0member),params0_0.wheelRadius_0member)));
          Release();
          RealPutSub( MbsLite_Util_Euler(platformCenter0_0, RealGetSub( 
            wheelCenters0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark), 
            initials0_0.vVec_0member, initials0_0.omegaVec_0member), wheelV0s0_0
             , Index, (Integer)( i0_0_0) ,Colon  , EndMark);
          Release();
          RealPutSub( RealAdd (initials0_0.omegaVec_0member,RealMultiplyMV (
            MbsLite_Util_Quaternions_QToT(RealGetSub( wheelQuaternionsAbs0_0 ,
             Index, (Integer)( i0_0_0) ,Colon  , EndMark)),wheelOmegaRelLocal0_0)),
             wheelOmega0s0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark);
          Release();
          {
            struct DymStruc1 dummy_DymStruc1;
            dummy_DymStruc1 = MbsLite_Examples_OmniVehicle_Initials(StringAdd(
              StringAdd("OmniWheel[",Integer2String2(i0_0_0, true, 0)),
              "] initials"), 1E+060, 1E+060, 1E+060, RealGetSub( wheelV0s0_0 ,
               Index, (Integer)( i0_0_0) ,Colon  , EndMark), RealGetSub( 
              wheelOmega0s0_0 , Index, (Integer)( i0_0_0) ,Colon  , EndMark));
            (*(struct DymStruc1*)RecordElement(wheelInitials0_0, i0_0_0, 1)).
              name_0member = dummy_DymStruc1.name_0member;
            (*(struct DymStruc1*)RecordElement(wheelInitials0_0, i0_0_0, 1)).
              omega_0member = dummy_DymStruc1.omega_0member;
            RealAssign ((*(struct DymStruc1*)RecordElement(wheelInitials0_0, 
              i0_0_0, 1)).omegaVec_0member, dummy_DymStruc1.omegaVec_0member);
            (*(struct DymStruc1*)RecordElement(wheelInitials0_0, i0_0_0, 1)).
              vAbs_0member = dummy_DymStruc1.vAbs_0member;
            (*(struct DymStruc1*)RecordElement(wheelInitials0_0, i0_0_0, 1)).
              vDirAngle_0member = dummy_DymStruc1.vDirAngle_0member;
            RealAssign ((*(struct DymStruc1*)RecordElement(wheelInitials0_0, 
              i0_0_0, 1)).vVec_0member, dummy_DymStruc1.vVec_0member);
          }
          Release();
        }
      }
      {
        struct DymStruc2 dummy_DymStruc2;
        dummy_DymStruc2 = MbsLite_Examples_OmniVehicle_OmniVehicleParams(
          params0_0, initials0_0, gravity0_0, platformQuaternion0_0, 
          platformCenter0_0, wheelCenters0_0, wheelAxisDirections0_0, 
          wheelQuaternionsAbs0_0, wheelInitials0_0);
        RealAssign (omniVehicleParams0_0.gravity_0member, dummy_DymStruc2.gravity_0member);
        omniVehicleParams0_0.initials_0member.name_0member = dummy_DymStruc2.initials_0member.name_0member;
        omniVehicleParams0_0.initials_0member.omega_0member = dummy_DymStruc2.initials_0member.omega_0member;
        RealAssign (omniVehicleParams0_0.initials_0member.omegaVec_0member, 
          dummy_DymStruc2.initials_0member.omegaVec_0member);
        omniVehicleParams0_0.initials_0member.vAbs_0member = dummy_DymStruc2.initials_0member.vAbs_0member;
        omniVehicleParams0_0.initials_0member.vDirAngle_0member = 
          dummy_DymStruc2.initials_0member.vDirAngle_0member;
        RealAssign (omniVehicleParams0_0.initials_0member.vVec_0member, 
          dummy_DymStruc2.initials_0member.vVec_0member);
        omniVehicleParams0_0.params_0member.NWheels_0member = dummy_DymStruc2.params_0member.NWheels_0member;
        omniVehicleParams0_0.params_0member.mecanumAngle_0member = 
          dummy_DymStruc2.params_0member.mecanumAngle_0member;
        omniVehicleParams0_0.params_0member.nRollers_0member = dummy_DymStruc2.params_0member.nRollers_0member;
        omniVehicleParams0_0.params_0member.name_0member = dummy_DymStruc2.params_0member.name_0member;
        omniVehicleParams0_0.params_0member.platformAxialMoi_0member = 
          dummy_DymStruc2.params_0member.platformAxialMoi_0member;
        omniVehicleParams0_0.params_0member.platformMass_0member = 
          dummy_DymStruc2.params_0member.platformMass_0member;
        omniVehicleParams0_0.params_0member.platformOrthogonalMoi_0member = 
          dummy_DymStruc2.params_0member.platformOrthogonalMoi_0member;
        omniVehicleParams0_0.params_0member.platformRadius_0member = 
          dummy_DymStruc2.params_0member.platformRadius_0member;
        omniVehicleParams0_0.params_0member.rollerAxialMoi_0member = 
          dummy_DymStruc2.params_0member.rollerAxialMoi_0member;
        omniVehicleParams0_0.params_0member.rollerHalfAngle_0member = 
          dummy_DymStruc2.params_0member.rollerHalfAngle_0member;
        omniVehicleParams0_0.params_0member.rollerLength_0member = 
          dummy_DymStruc2.params_0member.rollerLength_0member;
        omniVehicleParams0_0.params_0member.rollerMass_0member = 
          dummy_DymStruc2.params_0member.rollerMass_0member;
        omniVehicleParams0_0.params_0member.rollerOrthogonalMoi_0member = 
          dummy_DymStruc2.params_0member.rollerOrthogonalMoi_0member;
        omniVehicleParams0_0.params_0member.rollerRadius_0member = 
          dummy_DymStruc2.params_0member.rollerRadius_0member;
        omniVehicleParams0_0.params_0member.wheelHubAxialMoi_0member = 
          dummy_DymStruc2.params_0member.wheelHubAxialMoi_0member;
        omniVehicleParams0_0.params_0member.wheelHubMass_0member = 
          dummy_DymStruc2.params_0member.wheelHubMass_0member;
        omniVehicleParams0_0.params_0member.wheelHubOrthogonalMoi_0member = 
          dummy_DymStruc2.params_0member.wheelHubOrthogonalMoi_0member;
        omniVehicleParams0_0.params_0member.wheelHubRadius_0member = 
          dummy_DymStruc2.params_0member.wheelHubRadius_0member;
        omniVehicleParams0_0.params_0member.wheelRadius_0member = 
          dummy_DymStruc2.params_0member.wheelRadius_0member;
        RealAssign (omniVehicleParams0_0.platformCenter_0member, 
          dummy_DymStruc2.platformCenter_0member);
        RealAssign (omniVehicleParams0_0.platformQuaternion_0member, 
          dummy_DymStruc2.platformQuaternion_0member);
        RealAssign (omniVehicleParams0_0.wheelAxisDirections_0member, 
          dummy_DymStruc2.wheelAxisDirections_0member);
        RealAssign (omniVehicleParams0_0.wheelCenters_0member, dummy_DymStruc2.wheelCenters_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           1, 1)).name_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).name_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           1, 1)).omega_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).omega_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 1, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).omegaVec_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           1, 1)).vAbs_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).vAbs_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           1, 1)).vDirAngle_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).vDirAngle_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 1, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 1, 1)).vVec_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           2, 1)).name_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).name_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           2, 1)).omega_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).omega_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 2, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).omegaVec_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           2, 1)).vAbs_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).vAbs_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           2, 1)).vDirAngle_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).vDirAngle_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 2, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 2, 1)).vVec_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           3, 1)).name_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).name_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           3, 1)).omega_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).omega_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 3, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).omegaVec_0member);
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           3, 1)).vAbs_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).vAbs_0member;
        (*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.wheelInitials_0member,
           3, 1)).vDirAngle_0member = (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).vDirAngle_0member;
        RealAssign ((*(struct DymStruc1*)RecordElement(omniVehicleParams0_0.
          wheelInitials_0member, 3, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(dummy_DymStruc2.wheelInitials_0member, 3, 1)).vVec_0member);
        RealAssign (omniVehicleParams0_0.wheelQuaternions_0member, 
          dummy_DymStruc2.wheelQuaternions_0member);
      }
      Release();
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return omniVehicleParams0_0;
  }}
/* Flattened Modelica model:

function MbsLite.Examples.OmniVehicle.Initials
  input String name;
  input Real omega;
  input Real vAbs;
  input Real vDirAngle "angle between inertial X axis and vehicle's X axis counter-clockwise-positive looking from the end of Z axis";
  input Real vVec[3];
  input Real omegaVec[3];
  output MbsLite.Examples.OmniVehicle.Initials _out := MbsLite.Examples.OmniVehicle.Initials
    (
    name = name, 
    omega = omega, 
    vAbs = vAbs, 
    vDirAngle = vDirAngle, 
    vVec = vVec, 
    omegaVec = omegaVec
  );

algorithm 
end MbsLite.Examples.OmniVehicle.Initials;
*/



DYMOLA_STATIC struct DymStruc1  MbsLite_Examples_OmniVehicle_Initials(
  const char*  name0_0, double  omega0_0, double  vAbs0_0, double  vDirAngle0_0,
   RealArray   vVec0_0, RealArray   omegaVec0_0) {
  PushContext("MbsLite.Examples.OmniVehicle.Initials")
  AssertModelica(RealSize( vVec0_0,1)==3,"size(vVec, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( omegaVec0_0,1)==3,"size(omegaVec, 1) == 3","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    struct DymStruc1  x_0out;
    MarkObject retmark_ = PushMark();
    x_0out.name_0member = name0_0;
    x_0out.omega_0member = omega0_0;
    x_0out.vAbs_0member = vAbs0_0;
    x_0out.vDirAngle_0member = vDirAngle0_0;
    x_0out.vVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.vVec_0member, vVec0_0);
    Release();
    x_0out.omegaVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.omegaVec_0member, omegaVec0_0);
    Release();
    /* Start of real code */
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return x_0out;
  }}
/* Flattened Modelica model:

function MbsLite.Examples.OmniVehicle.OmniVehicleParams
  input MbsLite.Examples.OmniVehicle.Params params;
  input MbsLite.Examples.OmniVehicle.Initials initials;
  input Real gravity[3];
  input Real platformQuaternion[4];
  input Real platformCenter[3];
  input Real wheelCenters[:, 3];
  input Real wheelAxisDirections[:, 3];
  input Real wheelQuaternions[:, 4];
  input MbsLite.Examples.OmniVehicle.Initials wheelInitials[3];
  output MbsLite.Examples.OmniVehicle.OmniVehicleParams _out := MbsLite.Examples.OmniVehicle.OmniVehicleParams
    (
    params = params, 
    initials = initials, 
    gravity = gravity, 
    platformQuaternion = platformQuaternion, 
    platformCenter = platformCenter, 
    wheelCenters = wheelCenters, 
    wheelAxisDirections = wheelAxisDirections, 
    wheelQuaternions = wheelQuaternions, 
    wheelInitials = wheelInitials
  );

algorithm 
end MbsLite.Examples.OmniVehicle.OmniVehicleParams;
*/



DYMOLA_STATIC struct DymStruc2  MbsLite_Examples_OmniVehicle_OmniVehicleParams(
  struct DymStruc0 params0_0, struct DymStruc1 initials0_0, RealArray   
  gravity0_0, RealArray   platformQuaternion0_0, RealArray   platformCenter0_0, 
  RealArray   wheelCenters0_0, RealArray   wheelAxisDirections0_0, RealArray   
  wheelQuaternions0_0, RealArray wheelInitials0_0) {
  PushContext("MbsLite.Examples.OmniVehicle.OmniVehicleParams")
  AssertModelica(RealSize( gravity0_0,1)==3,"size(gravity, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( platformQuaternion0_0,1)==4,"size(platformQuaternion, 1) == 4","Dimension check of input to function failed");
  AssertModelica(RealSize( platformCenter0_0,1)==3,"size(platformCenter, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( wheelCenters0_0,2)==3,"size(wheelCenters, 2) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( wheelAxisDirections0_0,2)==3,"size(wheelAxisDirections, 2) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( wheelQuaternions0_0,2)==4,"size(wheelQuaternions, 2) == 4","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    struct DymStruc2  x_0out;
    MarkObject retmark_ = PushMark();
    x_0out.params_0member.name_0member = params0_0.name_0member;
    x_0out.params_0member.NWheels_0member = params0_0.NWheels_0member;
    x_0out.params_0member.nRollers_0member = params0_0.nRollers_0member;
    x_0out.params_0member.mecanumAngle_0member = params0_0.mecanumAngle_0member;
    x_0out.params_0member.platformRadius_0member = params0_0.platformRadius_0member;
    x_0out.params_0member.wheelRadius_0member = params0_0.wheelRadius_0member;
    x_0out.params_0member.platformMass_0member = params0_0.platformMass_0member;
    x_0out.params_0member.wheelHubMass_0member = params0_0.wheelHubMass_0member;
    x_0out.params_0member.rollerMass_0member = params0_0.rollerMass_0member;
    x_0out.params_0member.rollerHalfAngle_0member = params0_0.rollerHalfAngle_0member;
    x_0out.params_0member.wheelHubRadius_0member = params0_0.wheelHubRadius_0member;
    x_0out.params_0member.rollerRadius_0member = params0_0.rollerRadius_0member;
    x_0out.params_0member.rollerLength_0member = params0_0.rollerLength_0member;
    x_0out.params_0member.platformAxialMoi_0member = params0_0.platformAxialMoi_0member;
    x_0out.params_0member.platformOrthogonalMoi_0member = params0_0.
      platformOrthogonalMoi_0member;
    x_0out.params_0member.wheelHubAxialMoi_0member = params0_0.wheelHubAxialMoi_0member;
    x_0out.params_0member.wheelHubOrthogonalMoi_0member = params0_0.
      wheelHubOrthogonalMoi_0member;
    x_0out.params_0member.rollerAxialMoi_0member = params0_0.rollerAxialMoi_0member;
    x_0out.params_0member.rollerOrthogonalMoi_0member = params0_0.
      rollerOrthogonalMoi_0member;
    x_0out.initials_0member.name_0member = initials0_0.name_0member;
    x_0out.initials_0member.omega_0member = initials0_0.omega_0member;
    x_0out.initials_0member.vAbs_0member = initials0_0.vAbs_0member;
    x_0out.initials_0member.vDirAngle_0member = initials0_0.vDirAngle_0member;
    x_0out.initials_0member.vVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.initials_0member.vVec_0member, initials0_0.vVec_0member);
    Release();
    x_0out.initials_0member.omegaVec_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.initials_0member.omegaVec_0member, initials0_0.
      omegaVec_0member);
    Release();
    x_0out.gravity_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.gravity_0member, gravity0_0);
    Release();
    x_0out.platformQuaternion_0member=RealTemporary( 1, 4);
    RePushMark(&retmark_);
    RealAssign (x_0out.platformQuaternion_0member, platformQuaternion0_0);
    Release();
    x_0out.platformCenter_0member=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.platformCenter_0member, platformCenter0_0);
    Release();
    x_0out.wheelCenters_0member=RealTemporary( 2, RealSize( wheelCenters0_0, 1),
       3);
    RePushMark(&retmark_);
    RealAssign (x_0out.wheelCenters_0member, wheelCenters0_0);
    Release();
    x_0out.wheelAxisDirections_0member=RealTemporary( 2, RealSize( 
      wheelAxisDirections0_0, 1), 3);
    RePushMark(&retmark_);
    RealAssign (x_0out.wheelAxisDirections_0member, wheelAxisDirections0_0);
    Release();
    x_0out.wheelQuaternions_0member=RealTemporary( 2, RealSize( wheelQuaternions0_0,
       1), 4);
    RePushMark(&retmark_);
    RealAssign (x_0out.wheelQuaternions_0member, wheelQuaternions0_0);
    Release();
    x_0out.wheelInitials_0member=RealTemporary(2, 3, (sizeof(struct DymStruc1)+sizeof(Real)-1)/sizeof(Real));
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      name_0member="";
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      omega_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       1, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       1, 1)).omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      name_0member="";
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      omega_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       2, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       2, 1)).omegaVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      name_0member="";
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      omega_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      vAbs_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      vDirAngle_0member=0;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).vVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       3, 1)).vVec_0member, 0);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).omegaVec_0member
      =RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       3, 1)).omegaVec_0member, 0);
    RePushMark(&retmark_);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      name_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1))
      .name_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      omega_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 
      1)).omega_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       1, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(
      wheelInitials0_0, 1, 1)).omegaVec_0member);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      vAbs_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1, 1))
      .vAbs_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 1, 1)).
      vDirAngle_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 1,
       1)).vDirAngle_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       1, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(wheelInitials0_0,
       1, 1)).vVec_0member);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      name_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1))
      .name_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      omega_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 
      1)).omega_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       2, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(
      wheelInitials0_0, 2, 1)).omegaVec_0member);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      vAbs_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2, 1))
      .vAbs_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 2, 1)).
      vDirAngle_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 2,
       1)).vDirAngle_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       2, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(wheelInitials0_0,
       2, 1)).vVec_0member);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      name_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1))
      .name_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      omega_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 
      1)).omega_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       3, 1)).omegaVec_0member, (*(struct DymStruc1*)RecordElement(
      wheelInitials0_0, 3, 1)).omegaVec_0member);
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      vAbs_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3, 1))
      .vAbs_0member;
    (*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member, 3, 1)).
      vDirAngle_0member = (*(struct DymStruc1*)RecordElement(wheelInitials0_0, 3,
       1)).vDirAngle_0member;
    RealAssign ((*(struct DymStruc1*)RecordElement(x_0out.wheelInitials_0member,
       3, 1)).vVec_0member, (*(struct DymStruc1*)RecordElement(wheelInitials0_0,
       3, 1)).vVec_0member);
    Release();
    /* Start of real code */
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return x_0out;
  }}
/* Flattened Modelica model:

function MbsLite.Util.Euler
  input Real origin[3];
  input Real point[3];
  input Real velocityOfOrigin[3];
  input Real omega[3];
  output Real velocityOfPoint[3];

algorithm 
  velocityOfPoint := velocityOfOrigin+cross(omega, point-origin);
annotation(Inline=true);
end MbsLite.Util.Euler;
*/



DYMOLA_STATIC RealArray    MbsLite_Util_Euler(RealArray   origin0_0, RealArray  
   point0_0, RealArray   velocityOfOrigin0_0, RealArray   omega0_0) {
  PushContext("MbsLite.Util.Euler")
  AssertModelica(RealSize( origin0_0,1)==3,"size(origin, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( point0_0,1)==3,"size(point, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( velocityOfOrigin0_0,1)==3,"size(velocityOfOrigin, 1) == 3","Dimension check of input to function failed");
  AssertModelica(RealSize( omega0_0,1)==3,"size(omega, 1) == 3","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    RealArray    velocityOfPoint0_0;
    MarkObject retmark_ = PushMark();
    velocityOfPoint0_0=RealTemporary( 1, 3);
    RePushMark(&retmark_);
    RealFillAssign( velocityOfPoint0_0, 0);
    /* Start of real code */
      RealAssign (velocityOfPoint0_0, RealAdd (velocityOfOrigin0_0,Realcross( 
        omega0_0, RealSubtract (point0_0,origin0_0))));
      Release();
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return velocityOfPoint0_0;
  }}
/* Flattened Modelica model:

function MbsLite.Util.Quaternions.QMult
  input Real q1[4];
  input Real q2[4];
  output Real q3[4];
protected 
  Real a1;
  Real a2;
  Real A1[3];
  Real A2[3];
  Real A3[3];
  public 
algorithm 
  a1 := q1[1];
  a2 := q2[1];
  A1 := {q1[2], q1[3], q1[4]};
  A2 := {q2[2], q2[3], q2[4]};
  A3 := a1*A2+a2*A1+cross(A1, A2);
  q3 := {a1*a2-A1*A2, A3[1], A3[2], A3[3]};
annotation(Inline=true);
end MbsLite.Util.Quaternions.QMult;
*/



DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QMult(RealArray   q10_0, 
  RealArray   q20_0) {
  PushContext("MbsLite.Util.Quaternions.QMult")
  AssertModelica(RealSize( q10_0,1)==4,"size(q1, 1) == 4","Dimension check of input to function failed");
  AssertModelica(RealSize( q20_0,1)==4,"size(q2, 1) == 4","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    RealArray    q30_0;
    double   a10_0;
    double   a20_0;
    RealArray    A10_0;
    RealArray    A20_0;
    RealArray    A30_0;
    MarkObject retmark_ = PushMark();
    q30_0=RealTemporary( 1, 4);
    RePushMark(&retmark_);
    RealFillAssign( q30_0, 0);
    a10_0=0;
    a20_0=0;
    A10_0=RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( A10_0, 0);
    A20_0=RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( A20_0, 0);
    A30_0=RealTemporary( 1, 3);
    PushMark();
    RealFillAssign( A30_0, 0);
    /* Start of real code */
      a10_0 = RealVectorElement( q10_0, (SizeType)( 1 ));
      a20_0 = RealVectorElement( q20_0, (SizeType)( 1 ));
      RealAssign (A10_0, RealScalarArray ( 3, RealVectorElement( q10_0, 
        (SizeType)( 2 )), RealVectorElement( q10_0, (SizeType)( 3 )), 
        RealVectorElement( q10_0, (SizeType)( 4 ))));
      Release();
      RealAssign (A20_0, RealScalarArray ( 3, RealVectorElement( q20_0, 
        (SizeType)( 2 )), RealVectorElement( q20_0, (SizeType)( 3 )), 
        RealVectorElement( q20_0, (SizeType)( 4 ))));
      Release();
      RealAssign (A30_0, RealAdd (RealAdd (RealScale (A20_0,a10_0),RealScale (
        A10_0,a20_0)),Realcross( A10_0, A20_0)));
      Release();
      RealAssign (q30_0, RealScalarArray ( 4, a10_0*a20_0-RealMultiplyVV (A10_0,
        A20_0), RealVectorElement( A30_0, (SizeType)( 1 )), RealVectorElement( 
        A30_0, (SizeType)( 2 )), RealVectorElement( A30_0, (SizeType)( 3 ))));
      Release();
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return q30_0;
  }}
/* Flattened Modelica model:

function MbsLite.Util.Quaternions.QRot
  input Real angle;
  input Real axis[3];
  output Real q[4];
protected 
  Real s;
  public 
algorithm 
  s := sin(0.5*angle);
  q := {cos(0.5*angle), s*axis[1], s*axis[2], s*axis[3]};
annotation(Inline=true);
end MbsLite.Util.Quaternions.QRot;
*/



DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QRot(double  angle0_0, 
  RealArray   axis0_0) {
  PushContext("MbsLite.Util.Quaternions.QRot")
  AssertModelica(RealSize( axis0_0,1)==3,"size(axis, 1) == 3","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    RealArray    q0_0;
    double   s0_0;
    MarkObject retmark_ = PushMark();
    q0_0=RealTemporary( 1, 4);
    RePushMark(&retmark_);
    RealFillAssign( q0_0, 0);
    s0_0=0;
    /* Start of real code */
      s0_0 = sin(0.5*angle0_0);
      RealAssign (q0_0, RealScalarArray ( 4, cos(0.5*angle0_0), s0_0*
        RealVectorElement( axis0_0, (SizeType)( 1 )), s0_0*RealVectorElement( 
        axis0_0, (SizeType)( 2 )), s0_0*RealVectorElement( axis0_0, (SizeType)( 3
         ))));
      Release();
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return q0_0;
  }}
/* Flattened Modelica model:

function MbsLite.Util.Quaternions.QToT
  input Real q[4];
  output Real T[3, 3];

algorithm 
  T := [q[1]^2+q[2]^2-q[3]^2-q[4]^2, 2*(q[2]*q[3]-q[1]*q[4]), 2*(q[2]*q[4]+q[1]*
    q[3]); 2*(q[1]*q[4]+q[2]*q[3]), q[1]^2-q[2]^2+q[3]^2-q[4]^2, 2*(q[3]*q[4]-q[1]
    *q[2]); 2*(q[2]*q[4]-q[1]*q[3]), 2*(q[1]*q[2]+q[3]*q[4]), q[1]^2-q[2]^2-q[3]
    ^2+q[4]^2]/(q*q);
annotation(Inline=true);
end MbsLite.Util.Quaternions.QToT;
*/



DYMOLA_STATIC RealArray    MbsLite_Util_Quaternions_QToT(RealArray   q0_0) {
  PushContext("MbsLite.Util.Quaternions.QToT")
  AssertModelica(RealSize( q0_0,1)==4,"size(q, 1) == 4","Dimension check of input to function failed");
  {
    /* Declare outputs and temporaries */
    RealArray    T0_0;
    MarkObject retmark_ = PushMark();
    T0_0=RealTemporary( 2, 3, 3);
    RePushMark(&retmark_);
    RealFillAssign( T0_0, 0);
    /* Start of real code */
      RealAssign (T0_0, RealScaleDiv (RealCat( 1, 3, RealCat( 2, 3, 
        RealPromoteScalar( sqr(RealVectorElement( q0_0, (SizeType)( 1 )))+sqr(
        RealVectorElement( q0_0, (SizeType)( 2 )))-sqr(RealVectorElement( q0_0, 
        (SizeType)( 3 )))-sqr(RealVectorElement( q0_0, (SizeType)( 4 ))), 2), 
        RealPromoteScalar( 2*(RealVectorElement( q0_0, (SizeType)( 2 ))*
        RealVectorElement( q0_0, (SizeType)( 3 ))-RealVectorElement( q0_0, 
        (SizeType)( 1 ))*RealVectorElement( q0_0, (SizeType)( 4 ))), 2), 
        RealPromoteScalar( 2*(RealVectorElement( q0_0, (SizeType)( 2 ))*
        RealVectorElement( q0_0, (SizeType)( 4 ))+RealVectorElement( q0_0, 
        (SizeType)( 1 ))*RealVectorElement( q0_0, (SizeType)( 3 ))), 2)), 
        RealCat( 2, 3, RealPromoteScalar( 2*(RealVectorElement( q0_0, 
        (SizeType)( 1 ))*RealVectorElement( q0_0, (SizeType)( 4 ))+
        RealVectorElement( q0_0, (SizeType)( 2 ))*RealVectorElement( q0_0, 
        (SizeType)( 3 ))), 2), RealPromoteScalar( sqr(RealVectorElement( q0_0, 
        (SizeType)( 1 )))-sqr(RealVectorElement( q0_0, (SizeType)( 2 )))+sqr(
        RealVectorElement( q0_0, (SizeType)( 3 )))-sqr(RealVectorElement( q0_0, 
        (SizeType)( 4 ))), 2), RealPromoteScalar( 2*(RealVectorElement( q0_0, 
        (SizeType)( 3 ))*RealVectorElement( q0_0, (SizeType)( 4 ))-
        RealVectorElement( q0_0, (SizeType)( 1 ))*RealVectorElement( q0_0, 
        (SizeType)( 2 ))), 2)), RealCat( 2, 3, RealPromoteScalar( 2*(
        RealVectorElement( q0_0, (SizeType)( 2 ))*RealVectorElement( q0_0, 
        (SizeType)( 4 ))-RealVectorElement( q0_0, (SizeType)( 1 ))*
        RealVectorElement( q0_0, (SizeType)( 3 ))), 2), RealPromoteScalar( 2*(
        RealVectorElement( q0_0, (SizeType)( 1 ))*RealVectorElement( q0_0, 
        (SizeType)( 2 ))+RealVectorElement( q0_0, (SizeType)( 3 ))*
        RealVectorElement( q0_0, (SizeType)( 4 ))), 2), RealPromoteScalar( sqr(
        RealVectorElement( q0_0, (SizeType)( 1 )))-sqr(RealVectorElement( q0_0, 
        (SizeType)( 2 )))-sqr(RealVectorElement( q0_0, (SizeType)( 3 )))+sqr(
        RealVectorElement( q0_0, (SizeType)( 4 ))), 2))),RealMultiplyVV (q0_0,
        q0_0)));
      Release();
    /* Output section */
    PopMark(retmark_);
    PopContext()
    return T0_0;
  }}
/* DSblock C-code: */

#include <moutil.c>
DYMOLA_STATIC const char*modelName="MbsLite.Examples.OmniVehicle.CalculateOmniVehicleParams";
DYMOLA_STATIC const char*usedLibraries[]={0};
DYMOLA_STATIC const char*default_dymosim_license_filename=0;
#include <dsblock1.c>

struct DymStruc0  params0_0;
struct DymStruc1  initials0_0;
RealArray    gravity0_0;
RealArray    platformQuaternion0_0;
params0_0.NWheels_0member = IntegerReadScalar ( "funcin.mat" , "params.NWheels");
params0_0.mecanumAngle_0member = RealReadScalar ( "funcin.mat" , 
  "params.mecanumAngle");
params0_0.nRollers_0member = IntegerReadScalar ( "funcin.mat" , "params.nRollers");
params0_0.name_0member = StringReadScalar ( "funcin.mat" , "params.name");
params0_0.platformAxialMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.platformAxialMoi");
params0_0.platformMass_0member = RealReadScalar ( "funcin.mat" , 
  "params.platformMass");
params0_0.platformOrthogonalMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.platformOrthogonalMoi");
params0_0.platformRadius_0member = RealReadScalar ( "funcin.mat" , 
  "params.platformRadius");
params0_0.rollerAxialMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.rollerAxialMoi");
params0_0.rollerHalfAngle_0member = RealReadScalar ( "funcin.mat" , 
  "params.rollerHalfAngle");
params0_0.rollerLength_0member = RealReadScalar ( "funcin.mat" , 
  "params.rollerLength");
params0_0.rollerMass_0member = RealReadScalar ( "funcin.mat" , "params.rollerMass");
params0_0.rollerOrthogonalMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.rollerOrthogonalMoi");
params0_0.rollerRadius_0member = RealReadScalar ( "funcin.mat" , 
  "params.rollerRadius");
params0_0.wheelHubAxialMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.wheelHubAxialMoi");
params0_0.wheelHubMass_0member = RealReadScalar ( "funcin.mat" , 
  "params.wheelHubMass");
params0_0.wheelHubOrthogonalMoi_0member = RealReadScalar ( "funcin.mat" , 
  "params.wheelHubOrthogonalMoi");
params0_0.wheelHubRadius_0member = RealReadScalar ( "funcin.mat" , 
  "params.wheelHubRadius");
params0_0.wheelRadius_0member = RealReadScalar ( "funcin.mat" , "params.wheelRadius");
initials0_0.name_0member = StringReadScalar ( "funcin.mat" , "initials.name");
initials0_0.omega_0member = RealReadScalar ( "funcin.mat" , "initials.omega");
initials0_0.omegaVec_0member = RealReadArray ( "funcin.mat" , "initials.omegaVec"
   , 1);
initials0_0.vAbs_0member = RealReadScalar ( "funcin.mat" , "initials.vAbs");
initials0_0.vDirAngle_0member = RealReadScalar ( "funcin.mat" , "initials.vDirAngle");
initials0_0.vVec_0member = RealReadArray ( "funcin.mat" , "initials.vVec" , 1);
gravity0_0 = RealReadArray ( "funcin.mat" , "gravity" , 1);
platformQuaternion0_0 = RealReadArray ( "funcin.mat" , "platformQuaternion" , 1);

{
struct DymStruc2  omniVehicleParams0_0 = MbsLite_Examples_OmniVehicle_CalculateOmniVehicleParams
  (params0_0, initials0_0, gravity0_0, platformQuaternion0_0);
writeArrays("funcout.mat" , 37, "omniVehicleParams.gravity", doubleMatrix , 1, 
  omniVehicleParams0_0.gravity_0member, "omniVehicleParams.initials.name", 
  charMatrix , 0, omniVehicleParams0_0.initials_0member.name_0member, 
  "omniVehicleParams.initials.omega", doubleMatrix , 0, omniVehicleParams0_0.initials_0member.omega_0member,
   "omniVehicleParams.initials.omegaVec", doubleMatrix , 1, omniVehicleParams0_0.initials_0member.omegaVec_0member,
   "omniVehicleParams.initials.vAbs", doubleMatrix , 0, omniVehicleParams0_0.initials_0member.vAbs_0member,
   "omniVehicleParams.initials.vDirAngle", doubleMatrix , 0, omniVehicleParams0_0.initials_0member.vDirAngle_0member,
   "omniVehicleParams.initials.vVec", doubleMatrix , 1, omniVehicleParams0_0.initials_0member.vVec_0member,
   "omniVehicleParams.params.NWheels", integerMatrix , 0, omniVehicleParams0_0.params_0member.NWheels_0member,
   "omniVehicleParams.params.mecanumAngle", doubleMatrix , 0, omniVehicleParams0_0.params_0member.mecanumAngle_0member,
   "omniVehicleParams.params.nRollers", integerMatrix , 0, omniVehicleParams0_0.params_0member.nRollers_0member,
   "omniVehicleParams.params.name", charMatrix , 0, omniVehicleParams0_0.params_0member.name_0member,
   "omniVehicleParams.params.platformAxialMoi", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.platformAxialMoi_0member, "omniVehicleParams.params.platformMass",
   doubleMatrix , 0, omniVehicleParams0_0.params_0member.platformMass_0member, 
  "omniVehicleParams.params.platformOrthogonalMoi", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.platformOrthogonalMoi_0member, 
  "omniVehicleParams.params.platformRadius", doubleMatrix , 0, omniVehicleParams0_0.params_0member.platformRadius_0member,
   "omniVehicleParams.params.rollerAxialMoi", doubleMatrix , 0, omniVehicleParams0_0.params_0member.rollerAxialMoi_0member,
   "omniVehicleParams.params.rollerHalfAngle", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.rollerHalfAngle_0member, "omniVehicleParams.params.rollerLength",
   doubleMatrix , 0, omniVehicleParams0_0.params_0member.rollerLength_0member, 
  "omniVehicleParams.params.rollerMass", doubleMatrix , 0, omniVehicleParams0_0.params_0member.rollerMass_0member,
   "omniVehicleParams.params.rollerOrthogonalMoi", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.rollerOrthogonalMoi_0member, 
  "omniVehicleParams.params.rollerRadius", doubleMatrix , 0, omniVehicleParams0_0.params_0member.rollerRadius_0member,
   "omniVehicleParams.params.wheelHubAxialMoi", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.wheelHubAxialMoi_0member, "omniVehicleParams.params.wheelHubMass",
   doubleMatrix , 0, omniVehicleParams0_0.params_0member.wheelHubMass_0member, 
  "omniVehicleParams.params.wheelHubOrthogonalMoi", doubleMatrix , 0, 
  omniVehicleParams0_0.params_0member.wheelHubOrthogonalMoi_0member, 
  "omniVehicleParams.params.wheelHubRadius", doubleMatrix , 0, omniVehicleParams0_0.params_0member.wheelHubRadius_0member,
   "omniVehicleParams.params.wheelRadius", doubleMatrix , 0, omniVehicleParams0_0.params_0member.wheelRadius_0member,
   "omniVehicleParams.platformCenter", doubleMatrix , 1, omniVehicleParams0_0.platformCenter_0member,
   "omniVehicleParams.platformQuaternion", doubleMatrix , 1, omniVehicleParams0_0.platformQuaternion_0member,
   "omniVehicleParams.wheelAxisDirections", doubleMatrix , 2, omniVehicleParams0_0.wheelAxisDirections_0member,
   "omniVehicleParams.wheelCenters", doubleMatrix , 2, omniVehicleParams0_0.wheelCenters_0member,
   "omniVehicleParams.wheelInitials.name", charMatrix , 0, omniVehicleParams0_0.wheelInitials_0member.name_0member,
   "omniVehicleParams.wheelInitials.omega", doubleMatrix , 0, omniVehicleParams0_0.wheelInitials_0member.omega_0member,
   "omniVehicleParams.wheelInitials.omegaVec", doubleMatrix , 1, 
  omniVehicleParams0_0.wheelInitials_0member.omegaVec_0member, "omniVehicleParams.wheelInitials.vAbs",
   doubleMatrix , 0, omniVehicleParams0_0.wheelInitials_0member.vAbs_0member, 
  "omniVehicleParams.wheelInitials.vDirAngle", doubleMatrix , 0, 
  omniVehicleParams0_0.wheelInitials_0member.vDirAngle_0member, "omniVehicleParams.wheelInitials.vVec",
   doubleMatrix , 1, omniVehicleParams0_0.wheelInitials_0member.vVec_0member, 
  "omniVehicleParams.wheelQuaternions", doubleMatrix , 2, omniVehicleParams0_0.wheelQuaternions_0member);

}
{ FILE*f=fopen("success.","w");fclose(f);}
exit(0);

#include <dsblock6.c>
#define NX_    0
#define NX2_   0
#define NU_    0
#define NY_    0
#define NW_    0
#define NP_    0
#define NPS_   0
#define NHash1_ 0
#define NHash2_ 0
#define NHash3_ 0
#define NI_    0
#define NRelF_ 0
#define NRel_  0
#define NTim_  0
#define NSamp_ 0
#define NCons_ 0
#define NA_    0
#define SizePre_ 0
#define SizeEq_ 0
#define SizeDelay_ 0
#define QNLmax_ 0
#define MAXAux 0
#define NrDymolaTimers_ 0
#define NWhen_ 0
#define NCheckIf_ 0
#define NGlobalHelp_ 0
#ifndef NExternalObject_
#define NExternalObject_ 0
#endif

#include <dsblock5.c>

StartDataBlock
EndDataBlock
